SPOTIFY_CLIENT_ID = '85f648d4df314a5cb666b72f09c0c50e'
SPOTIFY_CLIENT_SECRET = '1e066b5c51ee4e32b2ec934b41527b76'
YOUTUBE_API_KEY = 'AIzaSyAMFInUKX-kgPjtJxIa7gBul4Zcw70snj4'

MONGO_URI = 'mongodb+srv://gabrielvictor:gabrielvictor@bancodedados.cmtvy.mongodb.net/?retryWrites=true&w=majority&appName=BancoDeDados'
MONGO_DB = 'media_insights'
